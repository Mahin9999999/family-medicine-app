package com.example.familymedicine

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.compose.rememberNavController
import com.example.familymedicine.navigation.NavGraph

@Composable
fun FamilyApp() {
    val navController = rememberNavController()
    val appSession = remember { AppSession() }

    MaterialTheme {
        NavGraph(
            navController = navController,
            session = appSession
        )
    }
}

/**
 * Temporary in-memory session.
 * Later we will persist (DataStore) and add biometric/PIN flow.
 */
class AppSession {
    var isLoggedIn: Boolean = false
    var isUnlocked: Boolean = true
    var familyId: String = "family_001"
    var ownerId: String = "owner_001"
}

