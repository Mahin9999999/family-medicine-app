package com.example.familymedicine.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.familymedicine.data.entity.FamilyMemberEntity

@Dao
interface FamilyMemberDao {
    @Query("SELECT * FROM family_members WHERE ownerId = :ownerId AND familyId = :familyId ORDER BY name")
    suspend fun getMembers(ownerId: String, familyId: String): List<FamilyMemberEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(member: FamilyMemberEntity)
}

