package com.example.familymedicine.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medicine_plans")
data class MedicinePlanEntity(
    @PrimaryKey val planId: String,
    val familyId: String,
    val memberId: String,

    val medicineName: String,
    val doseText: String,

    val frequencyPerDay: Int,
    val beforeAfterFood: String,

    val startDateMillis: Long,
    val endDateMillis: Long? = null,

    // For MVP alarms: we store up to 3 times-of-day millis (relative to a day) in minutes.
    val morningMinutes: Int? = null,
    val noonMinutes: Int? = null,
    val nightMinutes: Int? = null,

    val notes: String? = null
)

