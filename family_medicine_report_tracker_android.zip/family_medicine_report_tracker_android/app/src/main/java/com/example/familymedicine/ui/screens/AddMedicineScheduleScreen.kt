package com.example.familymedicine.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.familymedicine.ui.components.MedicalCard
import com.example.familymedicine.ui.components.MedicalTextField
import com.example.familymedicine.ui.components.PrimaryButton
import androidx.room.Room
import com.example.familymedicine.data.AppDatabase
import com.example.familymedicine.data.entity.MedicinePlanEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun AddMedicineScheduleScreen(
    onDone: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val db = remember {
        Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "family_medicine_db"
        ).build()
    }

    val medicineName = remember { mutableStateOf("") }
    val dose = remember { mutableStateOf("") }
    val beforeAfter = remember { mutableStateOf("After food") }
    val morningEnabled = remember { mutableStateOf(true) }
    val noonEnabled = remember { mutableStateOf(false) }
    val nightEnabled = remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            androidx.compose.foundation.layout.Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Add medicine schedule", style = MaterialTheme.typography.titleLarge)
                Icon(Icons.Filled.Add, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Text("Create a plan with times, dose confirmation & reminders (MVP placeholder).", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(Modifier.height(14.dp))

        MedicalCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MedicalTextField(
                    value = medicineName.value,
                    onValueChange = { medicineName.value = it },
                    label = "Medicine name",
                    placeholder = "e.g., Metformin",
                )
                MedicalTextField(
                    value = dose.value,
                    onValueChange = { dose.value = it },
                    label = "Dose",
                    placeholder = "e.g., 500 mg",
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "Timing", style = MaterialTheme.typography.titleMedium)
                    TimeToggle("Morning", morningEnabled.value) { morningEnabled.value = !morningEnabled.value }
                    TimeToggle("Noon", noonEnabled.value) { noonEnabled.value = !noonEnabled.value }
                    TimeToggle("Night", nightEnabled.value) { nightEnabled.value = !nightEnabled.value }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "Instruction", style = MaterialTheme.typography.titleMedium)
                    RowChips(
                        items = listOf("Before food", "After food"),
                        selected = beforeAfter.value,
                        onSelect = { beforeAfter.value = it }
                    )
                }

                PrimaryButton(
                    text = "Save schedule",
                    onClick = {
                        val planId = UUID.randomUUID().toString()
                        val familyId = "family_001" // TODO: connect owner/family from Firebase + session
                        val memberId = "m1" // TODO: pass memberId into this screen

                        val frequencyPerDay =
                            (if (morningEnabled.value) 1 else 0) +
                                (if (noonEnabled.value) 1 else 0) +
                                (if (nightEnabled.value) 1 else 0)

                        val morningMinutes = if (morningEnabled.value) 8 * 60 else null
                        val noonMinutes = if (noonEnabled.value) 14 * 60 else null
                        val nightMinutes = if (nightEnabled.value) 21 * 60 else null

                        val startMillis = System.currentTimeMillis()
                        val plan = MedicinePlanEntity(
                            planId = planId,
                            familyId = familyId,
                            memberId = memberId,
                            medicineName = medicineName.value.ifBlank { "Medicine" },
                            doseText = dose.value.ifBlank { "Dose" },
                            frequencyPerDay = frequencyPerDay.coerceAtLeast(1),
                            beforeAfterFood = beforeAfter.value,
                            startDateMillis = startMillis,
                            endDateMillis = null,
                            morningMinutes = morningMinutes,
                            noonMinutes = noonMinutes,
                            nightMinutes = nightMinutes,
                            notes = null
                        )

                        // Save locally. Next step: create reminder alarms + Firebase sync.
                        scope.launch(Dispatchers.IO) {
                            db.medicinePlanDao().upsert(plan)
                        }
                        onDone()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun TimeToggle(
    label: String,
    enabled: Boolean,
    onToggle: () -> Unit
) {
    OutlinedButton(
        onClick = onToggle,
        modifier = Modifier.fillMaxWidth(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(999.dp),
        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
            containerColor = if (enabled) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Text(text = "$label: " + if (enabled) "Enabled" else "Disabled")
    }
}

@Composable
private fun RowChips(
    items: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    androidx.compose.foundation.layout.Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items.forEach { item ->
            OutlinedButton(
                onClick = { onSelect(item) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(999.dp),
                modifier = Modifier.weight(1f),
                colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                    containerColor = if (item == selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Text(text = item)
            }
        }
    }
}

