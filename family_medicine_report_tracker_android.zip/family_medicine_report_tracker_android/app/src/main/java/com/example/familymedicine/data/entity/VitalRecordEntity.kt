package com.example.familymedicine.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vital_records")
data class VitalRecordEntity(
    @PrimaryKey val recordId: String,
    val familyId: String,
    val memberId: String,

    // e.g., "BP", "SUGAR", "WEIGHT", "TEMPERATURE"
    val vitalType: String,

    val valuePrimary: Double,
    val valueSecondary: Double? = null,

    val recordMillis: Long
)

