package com.example.familymedicine.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Ecology
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.familymedicine.ui.components.MedicalCard
import com.example.familymedicine.ui.theme.Error
import com.example.familymedicine.ui.theme.Secondary
import com.example.familymedicine.ui.theme.SecondaryContainer

@Composable
fun ProfessionalHealthAnalysisScreen(
    onBackToHome: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp)
    ) {
        RowTop(onBackToHome = onBackToHome, title = "Health analysis")
        Spacer(Modifier.height(14.dp))

        MedicalCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SummaryItem("BP trend", "Mostly stable", color = SecondaryContainer)
                SummaryItem("Blood sugar", "Within safe range", color = SecondaryContainer)
                SummaryItem("Weight trend", "Slight variation", color = SecondaryContainer)
                SummaryItem("Alert", "No critical signals detected", color = SecondaryContainer)
            }
        }

        Spacer(Modifier.height(14.dp))

        MedicalCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = "Chart preview (MVP placeholder)",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "In next step we will connect vitals records and draw weekly/monthly graphs with safe-range colors.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun RowTop(onBackToHome: () -> Unit, title: String) {
    Column {
        androidx.compose.foundation.layout.Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(onClick = onBackToHome) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null)
                Spacer(Modifier.height(1.dp))
                Text("Back")
            }
            Text(text = title, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun SummaryItem(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    androidx.compose.foundation.layout.Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium)
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

