package com.example.familymedicine.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "family_members")
data class FamilyMemberEntity(
    @PrimaryKey val memberId: String,
    val familyId: String,
    val ownerId: String,

    val name: String,
    val age: Int,
    val gender: String,
    val relation: String,

    val bloodGroup: String,
    val chronicConditions: String,
    val allergies: String,

    val emergencyContactName: String,
    val emergencyContactPhone: String
)

