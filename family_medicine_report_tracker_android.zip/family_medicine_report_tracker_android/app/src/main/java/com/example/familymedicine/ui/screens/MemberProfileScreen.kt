package com.example.familymedicine.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.familymedicine.ui.components.MedicalCard
import com.example.familymedicine.ui.components.PillTag

@Composable
fun MemberProfileScreen(
    memberId: String,
    onAddMedicine: () -> Unit,
    onMedicalHistory: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp)
        ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "Member profile", style = MaterialTheme.typography.titleLarge)
                Text(text = "ID: $memberId", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Filled.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }

        Spacer(Modifier.height(12.dp))

        MedicalCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.HealthAndSafety, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = "Father / Mother / Child (sample)", style = MaterialTheme.typography.titleMedium)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillTag("Blood Group: A+")
                    PillTag("Chronic: Diabetes")
                }

                Spacer(Modifier.height(4.dp))

                Button(onClick = onMedicalHistory, modifier = Modifier.fillMaxWidth()) {
                    Text("Open medical history")
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        MedicalCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "Daily meds (MVP placeholder)", style = MaterialTheme.typography.titleMedium)
                Text("Morning: Metformin - Taken / Missed")
                Text("Night: BP medicine - Pending")
                PrimaryMiniActions(onAddMedicine)
            }
        }
    }
}

@Composable
private fun PrimaryMiniActions(onAddMedicine: () -> Unit) {
    Spacer(Modifier.height(6.dp))
    com.example.familymedicine.ui.components.PrimaryButton(
        text = "Add medicine schedule",
        modifier = Modifier.fillMaxWidth(),
        onClick = onAddMedicine
    )
}

