package com.example.familymedicine.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medicine_dose_logs")
data class MedicineDoseLogEntity(
    @PrimaryKey val logId: String,
    val familyId: String,
    val planId: String,

    // Dose day (00:00 local time millis) to group logs per day.
    val doseDayMillis: Long,

    // 0 = pending, 1 = taken, 2 = missed
    val status: Int,
    val statusUpdatedAtMillis: Long,

    val missedReason: String? = null
)

