package com.example.familymedicine.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.familymedicine.AppSession
import com.example.familymedicine.ui.screens.AddMedicineScheduleScreen
import com.example.familymedicine.ui.screens.DoctorSummaryScreen
import com.example.familymedicine.ui.screens.FamilyMembersGridScreen
import com.example.familymedicine.ui.screens.HomeDashboardScreen
import com.example.familymedicine.ui.screens.LoginScreen
import com.example.familymedicine.ui.screens.MedicalHistoryScreen
import com.example.familymedicine.ui.screens.MemberProfileScreen
import com.example.familymedicine.ui.screens.OnboardingScreen
import com.example.familymedicine.ui.screens.OtpVerificationScreen
import com.example.familymedicine.ui.screens.PremiumSignUpScreen
import com.example.familymedicine.ui.screens.ProfessionalHealthAnalysisScreen
import com.example.familymedicine.ui.screens.SettingsScreen
import com.example.familymedicine.ui.screens.AppLockPinScreen

@Composable
fun NavGraph(
    navController: NavHostController,
    session: AppSession
) {
    NavHost(navController = navController, startDestination = Routes.Onboarding) {
        composable(Routes.Onboarding) {
            OnboardingScreen(
                onStart = {
                    navController.navigate(Routes.Login) {
                        popUpTo(Routes.Onboarding) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.Login) {
            LoginScreen(
                onLoginSuccess = {
                    session.isLoggedIn = true
                    navController.navigate(Routes.Otp) {
                        popUpTo(Routes.Login) { inclusive = true }
                    }
                },
                onCreateAccount = { navController.navigate(Routes.PremiumSignUp) }
            )
        }

        composable(Routes.Otp) {
            OtpVerificationScreen(
                onVerified = {
                    navController.navigate(Routes.Home) {
                        popUpTo(Routes.Otp) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.PremiumSignUp) {
            PremiumSignUpScreen(
                onDone = {
                    navController.navigate(Routes.Otp) {
                        popUpTo(Routes.PremiumSignUp) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.Home) {
            HomeDashboardScreen(
                onMembersClick = { navController.navigate(Routes.FamilyMembers) },
                onAnalysisClick = { navController.navigate(Routes.Analysis) },
                onHistoryClick = { navController.navigate(Routes.MedicalHistory) }
            )
        }

        composable(Routes.Analysis) {
            ProfessionalHealthAnalysisScreen(
                onBackToHome = { navController.navigate(Routes.Home) }
            )
        }

        composable(Routes.FamilyMembers) {
            FamilyMembersGridScreen(
                onMemberClick = { memberId ->
                    navController.navigate("${Routes.MemberProfile}/$memberId")
                },
                onAddMedicine = { navController.navigate(Routes.AddMedicine) }
            )
        }

        composable(
            route = "${Routes.MemberProfile}/{memberId}",
        ) { backStackEntry ->
            val memberId = backStackEntry.arguments?.getString("memberId") ?: "unknown"
            MemberProfileScreen(
                memberId = memberId,
                onAddMedicine = { navController.navigate(Routes.AddMedicine) },
                onMedicalHistory = { navController.navigate(Routes.MedicalHistory) }
            )
        }

        composable(Routes.MedicalHistory) {
            MedicalHistoryScreen(
                onAddMedicine = { navController.navigate(Routes.AddMedicine) }
            )
        }

        composable(Routes.AddMedicine) {
            AddMedicineScheduleScreen(
                onDone = { navController.navigate(Routes.Home) }
            )
        }

        composable(Routes.DoctorSummary) {
            DoctorSummaryScreen(
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.Settings) {
            SettingsScreen(
                onOpenLock = { navController.navigate(Routes.AppLock) }
            )
        }

        composable(Routes.AppLock) {
            AppLockPinScreen(
                session = session,
                onUnlocked = {
                    navController.popBackStack()
                }
            )
        }
    }
}

private object Routes {
    const val Onboarding = "onboarding"
    const val Login = "login"
    const val Otp = "otp"
    const val PremiumSignUp = "premium_signup"
    const val Home = "home"
    const val Analysis = "analysis"
    const val FamilyMembers = "family_members"
    const val MemberProfile = "member_profile"
    const val MedicalHistory = "medical_history"
    const val AddMedicine = "add_medicine"
    const val DoctorSummary = "doctor_summary"
    const val Settings = "settings"
    const val AppLock = "app_lock"
}

