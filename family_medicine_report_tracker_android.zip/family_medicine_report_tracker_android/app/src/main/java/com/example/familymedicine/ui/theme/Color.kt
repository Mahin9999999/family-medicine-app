package com.example.familymedicine.ui.theme

import androidx.compose.ui.graphics.Color

// Matches the provided Stitch design tokens (HTML/Tailwind).
val Primary = Color(0xFF005BB0)
val Secondary = Color(0xFF006C44)
val Tertiary = Color(0xFF944600)

val Surface = Color(0xFFF7FAFE)
val SurfaceContainerLow = Color(0xFFF1F4F8)
val SurfaceContainerLowest = Color(0xFFFFFFFF)

val OnSurface = Color(0xFF181C1F)
val OnSurfaceVariant = Color(0xFF414753)
val OutlineVariant = Color(0xFFC1C6D5)
val Error = Color(0xFFBA1A1A)
val SecondaryContainer = Color(0xFF7FFAB9)

