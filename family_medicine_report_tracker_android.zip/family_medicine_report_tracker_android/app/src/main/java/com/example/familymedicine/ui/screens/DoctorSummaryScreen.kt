package com.example.familymedicine.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.familymedicine.ui.components.MedicalCard
import com.example.familymedicine.ui.components.PillTag

@Composable
fun DoctorSummaryScreen(
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp)
    ) {
        androidx.compose.foundation.layout.Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Back")
            }
            Text("Doctor-ready summary", style = MaterialTheme.typography.titleLarge)
        }

        Spacer(Modifier.height(14.dp))

        MedicalCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                RowPill("Member: Father (sample)")
                RowPill("Main conditions: Hypertension, Diabetes")

                Text("Current medicines", style = MaterialTheme.typography.titleMedium)
                Text("1) BP medicine - 1 tab, twice daily")
                Text("2) Metformin - 500 mg, twice daily")

                Spacer(Modifier.height(6.dp))
                Text("Recent vitals (MVP placeholder)", style = MaterialTheme.typography.titleMedium)
                Text("BP: 128/82 (last record)")
                Text("Sugar: 98 mg/dL (last record)")

                Spacer(Modifier.height(6.dp))
                Text("Recent reports", style = MaterialTheme.typography.titleMedium)
                Text("CBC - 2026-03-05 (Normal)")
                Text("Lipid Profile - 2026-03-05 (High triglycerides)")
            }
        }
    }
}

@Composable
private fun RowPill(text: String) {
    PillTag(text = text, color = MaterialTheme.colorScheme.secondaryContainer)
}

