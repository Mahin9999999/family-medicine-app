package com.example.familymedicine.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.familymedicine.ui.components.MedicalCard
import com.example.familymedicine.ui.components.PrimaryButton
import com.example.familymedicine.ui.theme.SecondaryContainer

@Composable
fun OnboardingScreen(
    onStart: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Filled.Favorite,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "Family Medicine & Report Tracker",
                style = MaterialTheme.typography.headlineSmall
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Everything your family needs: prescriptions, lab reports, vitals & reminders.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(22.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            MedicalCard {
                RowFeature(icon = Icons.Filled.Description, color = Color(0xFF7FB7FF), title = "All health records in one place", desc = "Prescriptions, reports, vitals and vaccines—organized by family member.")
            }
            MedicalCard {
                RowFeature(icon = Icons.Filled.Alarm, color = SecondaryContainer, title = "Smart medicine reminders", desc = "Custom times + taken/missed confirmation to reduce dose misses.")
            }
            MedicalCard {
                RowFeature(icon = Icons.Filled.Group, color = Color(0xFFFFE0B8), title = "Family connection & care", desc = "Caregivers can monitor medicine status based on access settings.")
            }
            MedicalCard {
                RowFeature(icon = Icons.Filled.Description, color = Color(0xFFD6E3FF), title = "Doctor-ready summary", desc = "Generate a clean read-only summary via QR / share link.")
            }

            Spacer(Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PrimaryButton(
                    text = "Get started",
                    onClick = onStart
                )
                Text(
                    text = "Already have an account? Login",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun RowFeature(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    title: String,
    desc: String
) {
    androidx.compose.foundation.layout.Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(2.dp)
    ) {
        androidx.compose.foundation.layout.Box(
            modifier = Modifier
                .padding(end = 12.dp)
                .background(color = color, shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp))
                .padding(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White
            )
        }
        androidx.compose.foundation.layout.Column {
            Text(text = title, style = MaterialTheme.typography.titleMedium)
            Text(text = desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

