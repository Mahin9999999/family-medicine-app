package com.example.familymedicine.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.familymedicine.data.entity.MedicinePlanEntity

@Dao
interface MedicinePlanDao {
    @Query("SELECT * FROM medicine_plans WHERE familyId = :familyId AND memberId = :memberId ORDER BY startDateMillis DESC")
    suspend fun getPlansForMember(familyId: String, memberId: String): List<MedicinePlanEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(plan: MedicinePlanEntity)
}

