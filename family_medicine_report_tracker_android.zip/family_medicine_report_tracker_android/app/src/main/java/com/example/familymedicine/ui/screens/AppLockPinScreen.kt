package com.example.familymedicine.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.familymedicine.AppSession
import com.example.familymedicine.ui.components.MedicalCard
import com.example.familymedicine.ui.components.PrimaryButton

@Composable
fun AppLockPinScreen(
    session: AppSession,
    onUnlocked: () -> Unit
) {
    val pin = remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Icon(
            imageVector = Icons.Filled.Lock,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(10.dp))
        Text(text = "Enter PIN", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(6.dp))
        Text(
            text = "Unlock to access your family health data.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(18.dp))

        MedicalCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    repeat(4) { index ->
                        val char = pin.value.getOrNull(index)?.toString() ?: ""
                        OutlinedTextField(
                            value = char,
                            onValueChange = { newChar ->
                                val clean = newChar.take(1).filter { it.isDigit() }
                                val chars = pin.value.padEnd(4).toCharArray().map { if (it == '\u0000') ' ' else it }.toMutableList()
                                if (clean.isNotEmpty()) chars[index] = clean[0]
                                pin.value = chars.joinToString("").replace(" ", "")
                            },
                            keyboardOptions = androidx.compose.ui.text.input.KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }

                PrimaryButton(
                    text = "Unlock",
                    onClick = {
                        // Later: validate against stored PIN and persist lock state.
                        session.isUnlocked = true
                        onUnlocked()
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

