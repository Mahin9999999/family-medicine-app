package com.example.familymedicine.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = Primary,
    secondary = Secondary,
    tertiary = Tertiary,
    background = Surface,
    surface = Surface,
    surfaceVariant = SurfaceContainerLow,
    onSurface = OnSurface,
    onSurfaceVariant = OnSurfaceVariant,
    outline = OutlineVariant,
    error = Error,
)

@Composable
fun FamilyMedicineTheme(content: @Composable () -> Unit) {
    // Design is intended for modern light UI; dark can be added later.
    MaterialTheme(
        colorScheme = LightColors,
        content = content
    )
}

