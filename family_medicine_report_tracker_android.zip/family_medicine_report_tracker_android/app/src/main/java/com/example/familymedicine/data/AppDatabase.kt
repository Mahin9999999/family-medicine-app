package com.example.familymedicine.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.familymedicine.data.dao.FamilyMemberDao
import com.example.familymedicine.data.dao.MedicineDoseLogDao
import com.example.familymedicine.data.dao.MedicinePlanDao
import com.example.familymedicine.data.dao.VitalRecordDao
import com.example.familymedicine.data.entity.FamilyMemberEntity
import com.example.familymedicine.data.entity.MedicineDoseLogEntity
import com.example.familymedicine.data.entity.MedicinePlanEntity
import com.example.familymedicine.data.entity.VitalRecordEntity

@Database(
    entities = [
        FamilyMemberEntity::class,
        MedicinePlanEntity::class,
        MedicineDoseLogEntity::class,
        VitalRecordEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun familyMemberDao(): FamilyMemberDao
    abstract fun medicinePlanDao(): MedicinePlanDao
    abstract fun medicineDoseLogDao(): MedicineDoseLogDao
    abstract fun vitalRecordDao(): VitalRecordDao
}

