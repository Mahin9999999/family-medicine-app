package com.example.familymedicine.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.familymedicine.data.entity.MedicineDoseLogEntity

@Dao
interface MedicineDoseLogDao {
    @Query(
        "SELECT * FROM medicine_dose_logs WHERE familyId = :familyId AND planId = :planId AND doseDayMillis = :doseDayMillis"
    )
    suspend fun getLogs(familyId: String, planId: String, doseDayMillis: Long): List<MedicineDoseLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: MedicineDoseLogEntity)
}

