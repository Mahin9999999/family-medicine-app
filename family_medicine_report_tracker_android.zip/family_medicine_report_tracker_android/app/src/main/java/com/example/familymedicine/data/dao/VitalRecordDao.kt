package com.example.familymedicine.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.familymedicine.data.entity.VitalRecordEntity

@Dao
interface VitalRecordDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: VitalRecordEntity)

    @Query(
        "SELECT * FROM vital_records WHERE familyId = :familyId AND memberId = :memberId AND vitalType = :vitalType AND recordMillis BETWEEN :fromMillis AND :toMillis ORDER BY recordMillis ASC"
    )
    suspend fun getVitals(
        familyId: String,
        memberId: String,
        vitalType: String,
        fromMillis: Long,
        toMillis: Long
    ): List<VitalRecordEntity>
}

